# Activity 8
# Get inputs for hours worked and hourly rate
hour_work = float(input("Enter number of hours worked: "))
hourly_rate = float(input("Enter hourly rate: "))
# Calculate gross pay
gross_pay = hour_work * hourly_rate
print("Gross Pay: $", gross_pay)