# Activity 2
# Getting inputs for length and width of a rectangle
length = float(input("Please enter the length"))
width = float(input("Please enter the width"))  
# Calculating the area of the rectangle
area = length * width
# Printing the area
print(f"The area of the rectangle is {area}")