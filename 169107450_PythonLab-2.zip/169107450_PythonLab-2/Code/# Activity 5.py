# Activity 5
# The calculation of the area of a circle
pi = 3.1415959
radius = float(input("Enter the radius of the circle: "))
area = pi * radius ** 2
# the output
print("The area of the circle is:", area)


