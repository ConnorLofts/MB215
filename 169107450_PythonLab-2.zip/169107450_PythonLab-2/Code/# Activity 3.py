# Activity 3
string1 = input("Enter the first string: ")

string2 = input("Enter the second string: ")

string3 = input("Enter the third string: ")

# Combining the strings into a full sentence
full_sentence = string1 + " " + string2 + " " + string3 + "."

print(f"{full_sentence}")