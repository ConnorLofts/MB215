# Activity 1
Km = float(input("Enter distance in kilometers: "))
# Converting kilometers to miles
Miles = Km * (1/1.609)
# Rounding to 2 decimal places
Round_miles = round(Miles, 2)
# Displaying the result
print(f"{Km} kilometers is equal to {Round_miles} miles.")

