##Activity 1: Define a Car Class
##Create a file named car.py and define a Car class with the following ##specifications:
# car.py
class Car:
    def __init__(self, make, model, year):
        # Your code here to initialize attributes
        self.make = make
        self.model = model
        self.year = year
        pass
   