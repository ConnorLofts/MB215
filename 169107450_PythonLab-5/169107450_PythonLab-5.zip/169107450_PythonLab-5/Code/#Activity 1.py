#Activity 1.

my_list = [1, "two", 3.0, True]
print("The entire list:", my_list)
my_tuple = (4, "five", 6.0, False)
tuple_to_list = list(my_tuple)
print("Converted list from tuple:", tuple_to_list)
