##Activity 4
list1 = [1, 2, 3]
list2 = [4, 5, 6]
concatenated_list = list1 + list2
print("Concatenated list using + operator:", concatenated_list)

list1 = [1, 2, 3]
list2 = [4, 5, 6]
list1 += list2
print("Concatenated list using += operator:", list1)


list1 = [1, 2, 3]
number = 4
