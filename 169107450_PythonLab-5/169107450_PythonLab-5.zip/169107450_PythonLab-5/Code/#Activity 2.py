#Activity 2.
simple_list = ['a', 'b', 'c']
repeated_list = simple_list * 3
print("Repeated list:", repeated_list)
for element in repeated_list:
    print(element)
